package chap12;

public class Sample03 {
	public static void main(String[] args) {
		
	}
}

enum Color1{
	RED, BLUE, ORANGE;
}

enum Size1{
	SMALL, MIDIUM, LARGE;
}